(function($) {

  module('jQuery#gridmanager', {
    // This will run before each test in this module.
    setup: function() {
      this.elems = $('#qunit-fixture').children();
    }
  }); 
}(jQuery));
