#Bootstrap Tag Autocomplete

This is a bootstrap plugin to autocomplete tags for contenteditable div elements. It works in the same way tagging people on Facebook, Twitter or Sandglaz works.

#Demo and Documentation

<a href="http://sandglaz.github.com/bootstrap-tagautocomplete/">http://sandglaz.github.com/bootstrap-tagautocomplete/</a>

#Contributing

<a href="https://github.com/Sandglaz/bootstrap-tagautocomplete/issues">Bug reports</a> and <a href="https://github.com/Sandglaz/bootstrap-tagautocomplete/pulls">pull requests</a> are welcomed! If your pull request contains JavaScript patches or features, you must include relevant unit tests.

Thanks!