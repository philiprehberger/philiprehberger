#!/bin/bash
java -jar ../compiler-latest/compiler.jar --js lib/jquery.bootpag.js --js_output_file lib/jquery.bootpag.min.js
