## Contributors

bootstrap-table is due to the excellent work of the following contributors:

<table>
<tr>
<th>Author</th>
<th>Github</th>
<th>Location</th>
<th>Blog</th>
<th>Commits</th>
</tr>

<tr>
<td><img src="https://avatars.githubusercontent.com/u/2117018?" width="32" height="32"> <a href="mailto:wenzhixin2010@gmail.com">文翼</a></td>
<td><a href="https://github.com/wenzhixin">wenzhixin</a></td>
<td>Guangzhou, China</td>
<td><a href="http://wenzhixin.net.cn">http://wenzhixin.net.cn</a></td>
<td>150</td>
<tr>

</table>

Update date: 2014-07-17, created with https://github.com/wenzhixin/github-contributors